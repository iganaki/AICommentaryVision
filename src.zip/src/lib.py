import sys
import time
from config import OUTPUT_FOLDER

# グローバル変数でログファイルのパスを保持
current_log_file = None

def create_log_file(video_title='nontitle'):
    global current_log_file
    # ログファイルのパスを生成（日時情報を含む）
    current_log_file = f'{OUTPUT_FOLDER}/{video_title}_log_{int(time.time())}.txt'
    # 空のログファイルを作成
    with open(current_log_file, 'w', encoding='utf-8') as file:
        file.write('')
    return current_log_file

def write_to_log_file(tag, text):
    global current_log_file
    # 現在のログファイルパスを確認
    if current_log_file is None:
        # ログファイルが存在しない場合、新しいログファイルを作成
        current_log_file = create_log_file()

    # ログファイルの内容
    log = f'{tag} :\n{text}\n\n'

    # ログファイルに追記
    with open(current_log_file, 'a', encoding='utf-8') as file:
        file.write(log)

def update_dialogue_progress(total_duration_sec, current_time):
    progress_percentage = (current_time / total_duration_sec) * 100
    sys.stdout.write("\rProgress: {:.2f}% ({}sec/{}sec)".format(progress_percentage, current_time, total_duration_sec))
    sys.stdout.flush()